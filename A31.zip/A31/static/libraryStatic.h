#ifndef STATIC_LIBRARYSTATIC_H
#define STATIC_LIBRARYSTATIC_H

void hello(void);

void thidIsATestForStaticLibrary(int n);

#endif //STATIC_LIBRARYSTATIC_H
