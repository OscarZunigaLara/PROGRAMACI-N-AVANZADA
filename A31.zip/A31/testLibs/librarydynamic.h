#ifndef DYNAMIC_LIBRARYDYNAMIC_H
#define DYNAMIC_LIBRARYDYNAMIC_H

void hello(void);
void thisIsATestForADynamicLibrary(int n);
#endif //DYNAMIC_LIBRARYDYNAMIC_H
