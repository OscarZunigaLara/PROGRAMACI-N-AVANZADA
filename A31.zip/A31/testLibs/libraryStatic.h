#ifndef STATIC_LIBRARYSTATIC_H
#define STATIC_LIBRARYSTATIC_H


void thidIsATestForStaticLibrary(int n);
#endif //STATIC_LIBRARYSTATIC_H
